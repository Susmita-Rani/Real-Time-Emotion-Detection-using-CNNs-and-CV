📄 Instructions: Real-Time Emotion Detection

1. Make sure you have Python installed: https://www.python.org/downloads/
2. Open your terminal or command prompt.
3. Navigate to this folder using `cd` command.

4. Install dependencies:
   pip install tensorflow opencv-python

5. Place your trained model file `emotion_model.h5` in this same folder.

6. Run the script:
   python realtime_emotion_detector.py

7. Press 'q' to exit the webcam window.

Make sure your webcam is working.
